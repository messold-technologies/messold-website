var nodemailer = require('nodemailer');
var xml = require('xml');
const fetch = require("node-fetch");
const
{
    GoogleSpreadsheet
} = require('google-spreadsheet');
var TOKEN_DIR = (process.env.HOME || process.env.HOMEPATH || process.env.USERPROFILE) + '/.credentials/';
const admin = require('firebase-admin');
const serviceAccount = require('../parallels-firebase.json');
// var CronJob = require('cron').CronJob;
const cron = require("node-cron");
admin.initializeApp(
{
    credential: admin.credential.cert(serviceAccount)
});
const db = admin.firestore();
const doc = new GoogleSpreadsheet('1c_PGZSFLDa2gVdoexJCu7VZxPhSRvy72vITcEDuwH8g');
const Shopify = require('shopify-api-node');
// Set up your Shopify API credentials
const shopify = new Shopify(
{
    shopName: 'phuljadi.myshopify.com',
    apiKey: 'ab72dfbaad5d17c725a49090bed2d5f5',
    password: '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'
});
module.exports = function(app)
{
    app.get('/brandbind', function(req, res)
    {
        res.render('brandbind.html')
    })
    app.get('/', function(req, res)
    {
        res.render("index.html")
    });
    // app.get('/about', function(req, res) {
    //     res.render("about-us.html")
    // });
    app.post('/phuljhadi', function(req, res)
    {
        var cartitems = req.body;

        console.log((cartitems));
        // res.writeHead(200, { 'Content-Type': 'application/json' }); 
        // res.send('Done');
        // res.end(JSON.stringify({number:1}));
        // req.send(200)
        // res.status(200).send('some text');
        // console.log("aa",cartitems.discountamount,parseInt(cartitems.discountamount) );
        if (cartitems.discountamount != 0)
        {
            console.log(cartitems.discountamount)
            // parseInt(a.replace(/,/g, ''), 10);
            var amount = cartitems.discountamount;
            // console.log(amount);
            var amountreplaced = amount.replace(/,/g, '');
            var removefirst2 = parseInt(amountreplaced.slice(2));
            // console.log("parse", parseInt(removefirst2));
            //  var positive = Math.abs(parseInt(amount));
            //  console.log(positive);
            //  var pricewithoutdollar = positive.toString().replace(/,/g, '');
            // console.log(pricewithoutdollar)
            //  var finalamount = parseInt(pricewithoutdollar);
            //  console.log(finalamount)
            phuljhadi(res, cartitems, cartitems.discountcode, removefirst2)
        }
        else phuljhadi(res, cartitems, "Messold", 0)
    });
    // testing()
    //     function testing()
    //     {
    //         const collectionID = 123456789;
    //         const discountCode = {
    //             code: '3FOR1000',
    //             discount_type: 'fixed_amount',
    //             value: 1000,
    //             applies_to_resource:
    //             {
    //                 type: 'Collection',
    //                 value: collectionID.toString(),
    //             },
    //             usage_limit: 1,
    //             once_per_customer: true,
    //             starts_at: new Date().toISOString(),
    //         };
    //         // Define a function to apply or remove the discount code as needed
    //         const applyDiscount = async() =>
    //         {
    //             // Get the cart and check if the discount code is already applied
    //             const cart = await shopify.checkout.get();
    //             const discountApplied = cart.discount_codes.some(code => code.code === discountCode.code);
    //             // Get the product IDs in the cart
    //             const productIDs = cart.line_items.map(item => item.product_id);
    //             // Check if there are at least 3 products from the collection in the cart
    //             const collectionProducts = productIDs.filter(id =>
    //             {
    //                 return shopify.product.get(id).collection_id === collectionID;
    //             });
    //             const collectionCount = collectionProducts.length;
    //             // Apply or remove the discount code as needed
    //             if (collectionCount >= 3 && !discountApplied)
    //             {
    //                 await shopify.discount.create(discountCode);
    //             }
    //             else if (collectionCount < 3 && discountApplied)
    //             {
    //                 const discount = await shopify.discount.list(
    //                 {
    //                     code: discountCode.code
    //                 });
    //                 await shopify.discount.delete(discount[0].id);
    //             }
    //         };
    //         // Call the applyDiscount function whenever the cart is updated
    //         shopify.webhook.create(
    //         {
    //             topic: 'carts/update',
    //             address: 'https://messold.com/phuljhadi',
    //             format: 'json',
    //         });
    //     }
    //     app.post('/cart-updated', async function(req, res)
    //     {
    //         const cartitems = req.body;
    //         console.log(cartitems);
    //         await phuljhadi(cartitems, "MESSOLD", 0);
    //         res.json(cartitems);
    //     });
    async function phuljhadi(res, phuljhadicart, discountcode, discountamount)
    {
        var thousand = 0;
        var thousandqty = 0;
        var fifteenhundred = 0;
        var fifteenhundredqty = 0;
        var discount = discountamount;
        // console.log(phuljhadicart.resp)
        for (var i = 0; i < phuljhadicart.items.length; i++)
        {
            if (phuljhadicart.items[i].price == 699)
            {
                thousand = thousand + (parseInt(phuljhadicart.items[i].price) / 100);
                thousandqty = thousandqty + parseInt(phuljhadicart.items[i].quantity);
            }
            else if (phuljhadicart.items[i].price == 750)
            {
                fifteenhundred = fifteenhundred + (parseInt(phuljhadicart.items[i].price) / 100);
                fifteenhundredqty = fifteenhundredqty + parseInt(phuljhadicart.items[i].quantity);
            }
            else
            {
                discount = discount + (parseInt(phuljhadicart.items[i].total_discount) / 100);
            }
            lt['draft_order']['line_items'].push(
            {
                'variant_id': phuljhadicart.items[i].variant_id,
                'quantity': phuljhadicart.items[i].quantity
            })
        }
        if (thousandqty >= 2)
        {
            var remainder = thousandqty % 3;
            if (remainder == 2)
            {
                discount = discount + 598;
                discount = discount + (Math.floor(thousandqty / 3) * 1097);
            }
            else
            {
                discount = discount + (Math.floor(thousandqty / 3) * 1097);
            }
        }
        if (fifteenhundredqty >= 2)
        {
            var remainder = fifteenhundredqty % 3;
            if (remainder == 2)
            {
                discount = discount + 300;
                discount = discount + (Math.floor(fifteenhundredqty / 3) * 750);
            }
            else
            {
                discount = discount + (Math.floor(fifteenhundredqty / 3) * 750);
            }
        }
        console.log("total discount", discount);
        var request = require("request");
        var options = {
            method: 'POST',
            url: 'https://phuljadi.myshopify.com/admin/api/2023-04/draft_orders.json',
            headers:
            {
                "Content-Type": "application/json",
                "X-Shopify-Access-Token": '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'
            },
            json: true,
            body: lt
        };
        request(options, function(error, response, body)
        {
            console.log("---------->", JSON.stringify(lt))
            // console.log(body,access_token,orderNumber)
            if (error) throw new Error(error);
            else
            {
                console.log("sending", body.draft_order.invoice_url)
                res.status(200).send(body.draft_order.invoice_url);
                // res.send(body.draft_order.invoice_url)
                // console.log(body)
            }
        });
        // discount = 0;
    }
    app.post('/hubspot', (req, res) =>
    {
        console.log("Inside Post")
        console.log(req.body); // Log the incoming webhook notification
        res.status(200).send('OK');
    });
    app.get('/hubspot', (req, res) =>
    {
        console.log("Inside GET")
        console.log(req.body); // Log the incoming webhook notification
        res.status(200).send('OK');
    });
    app.get('/contact', function(req, res)
    {
        res.render("contact.html")
    });
    app.get('/privacy-policy', function(req, res)
    {
        res.render("privacy-policy.html")
    });
    app.get('/eligibility-form', function(req, res)
    {
        res.render("eligibility-form.html")
    });
    app.get('/budget', function(req, res)
    {
        res.render("fb-budget-calc.html")
    });
    app.get('/pricing-india', function(req, res)
    {
        res.render("pricing-india.html")
    });
    app.get('/pricing-india-retain', function(req, res)
    {
        res.render("pricing-india-retain.html")
    });
    app.get('/pricing-int', function(req, res)
    {
        res.render("pricing-int.html")
    });
    app.get('/pricing-int-retain', function(req, res)
    {
        res.render("pricing-int-retain.html")
    });
    app.get('/bindbrands', function(req, res)
    {
        res.render("bindbrands.html")
    })
    app.get('/form', function(req, res)
    {
        res.render('form.html')
    });
    // app.get('/sitemap.xml', function(req, res)
    // {
    //     // res.set('Content-Type', 'text/xml');
    //     // res.type('application/xml');
    //     // res.header('Content-Type', 'application/xml');
    //     res.sendFile(path.join(__dirname, '../views', 'sitemap.xml'));
    // });
    app.get('/parallel', function(req, res)
    {
        getAccess(req);
        res.send("Processing Data")
    });
    async function getAccess(req)
    {
        // console.log(req.body.websiteUrl)
        // console.log(req.body)
        const cityRef = db.collection("Messold").doc((req.body.websiteUrl));
        const doc = await cityRef.get();
        if (!doc.exists)
        {
            res.send('Wrong Brand name');
        }
        else
        {
            var docData = doc.data();
            var access_token = docData.access_token;
            var sheetId = docData.sheetId;
            var websiteUrl = req.body.websiteUrl;
            var orderNumber = req.body.orderNumber;
            // console.log(req.body);
            getOrder(orderNumber, websiteUrl, access_token, sheetId, req.body.sequence);
        }
    }
    // app.post('/phuljhadi', function(req, res)
    // {
    //     res.send(200)
    // });
    // function phuljhadi()
    // {
    //     var thousand = 0;
    //     var fifteenhundred = 0;
    //     var discount = 0;
    //     var lt = {
    //         "draft_order":
    //         {
    //             "line_items": []
    //         }
    //     }
    //     for (var i = 0; i < phuljhadicart.items.length; i++)
    //     {
    //         if (phuljhadicart.items[i].product_type == 1000)
    //         {
    //             thousand = thousand + phuljhadicart.items[i].quantity;
    //         }
    //         else if (phuljhadicart.items[i].product_type == 1500)
    //         {
    //             fifteenhundred = fifteenhundred + phuljhadicart.items[i].quantity
    //         }
    //         else
    //         {}
    //         lt['draft_order']['line_items'].push(
    //         {
    //             'variant_id': phuljhadicart.items[i].variant_id,
    //             'quantity': phuljhadicart.items[i].quantity
    //         })
    //     }
    //     if (thousand >= 3)
    //     {
    //         discount = discount + Math.floor(thousand / 3) * 1000;
    //     }
    //     if (fifteenhundred >= 3)
    //     {
    //         discount = discount + Math.floor(thousand / 3) * 1500;
    //     }
    //     lt['draft_order']['applied_discount'] = {
    //         "description": "Custom discount",
    //         "value_type": "fixed_amount",
    //         "value": discount,
    //         "amount": discount,
    //         "title": "Phuljhadi"
    //     };
    //     console.log(JSON.stringify(lt))
    //     var request = require("request");
    //     var options = {
    //         method: 'POST',
    //         url: 'https://phuljadi.myshopify.com/admin/api/2021-04/draft_orders.json',
    //         headers:
    //         {
    //             "Content-Type": "application/json",
    //             "X-Shopify-Access-Token": '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'
    //         },
    //         json: true,
    //         body: lt
    //     };
    //     request(options, function(error, response, body)
    //     {
    //         // console.log(body,access_token,orderNumber)
    //         if (error) throw new Error(error);
    //         else
    //         {
    //             console.log(body)
    //         }
    //     });
    //     // var n =  JSON.parse(m);
    //     // console.log("phul", m);
    //     // })
    // }
    // autosheet();
    // var job = new CronJob('* * * * * *', function()
    // {
    //     console.log("Cron Started", new Date())
    //     // autosheet();
    //     // console.log('Run Cron');
    // });
    // console.log(new Date())
    app.get('/getData', function(req, res)
    {
        autosheet();
        res.send("Processing Data")
    });
    console.log(new Date())
    cron.schedule("0 1,2,4,6 1 * *", function()
    {
        console.log("Cron Started", new Date());
        autosheet();
    },
    {
        scheduled: true,
        timezone: 'Asia/Kolkata'
    });
    async function autosheet()
    {
        const cityRef = db.collection("Messold");
        const snapshot = await cityRef.where('active', '==', true).get();
        if (snapshot.empty)
        {
            console.log('No matching documents.');
            return;
        }
        console.log(snapshot.length);
        snapshot.forEach(doc =>
        {
            var finalData = doc.data();
            var access_token = finalData.access_token;
            var sheetId = finalData.sheetId;
            var websiteUrl = doc.id;
            var orderNumber = finalData.orderNumber;
            // console.log(access_token, sheetId, websiteUrl, orderNumber);
            getOrder(orderNumber, websiteUrl, access_token, sheetId, 'continue')
            // console.log(doc.id, '=>', doc.data());
        })
        // const doc = await cityRef.orderBy('active').get();
        // console.log(doc.data);
    }
    async function getOrder(orderNumber, websiteUrl, access_token, sheetId, sequence)
    {
        console.log("Processing:", orderNumber, websiteUrl)
        var request = require("request");
        var options = {
            method: 'GET',
            url: 'https://' + websiteUrl + '/admin/api/2020-07/orders.json?name=' + orderNumber + '&status=any',
            headers:
            {
                "Content-Type": "application/json",
                "X-Shopify-Access-Token": access_token
            },
            json: true
        };
        request(options, function(error, response, body)
        {
            // console.log(body, access_token, orderNumber)
            if (error)
            {
                console.log("Error In GetOrder")
                throw new Error(error);
            }
            console.log("Under Request", websiteUrl);
            // console.log(body)
            if (body.errors) return;
            var orderData = body.orders[0];
            // console.log(orderData);
            if (orderData === 'undefined' || orderData === undefined)
            {
                saveDataFirebase1(websiteUrl, orderNumber)
            }
            if (!orderData) return;
            var todayDate = new Date();
            var currentOffset = todayDate.getTimezoneOffset();
            var ISTOffset = 330; // IST offset UTC +5:30 
            var ISTTime = new Date(todayDate.getTime() + (ISTOffset + currentOffset) * 60000);
            // console.log("Todays Date:",ISTTime)
            var currentdate = formatDate1(ISTTime);
            var orderDate = formatDate(orderData.created_at)
            // console.log(currentdate, orderDate)
            if (orderDate == currentdate)
            {
                // console.log("Finals")
                saveDataFirebase1(websiteUrl, orderData.order_number)
                // console.log(orderData)
                return;
            }
            else
            {
                getUTM(orderData, websiteUrl, access_token, sheetId, sequence)
            }
        });
    }

    function saveDataFirebase1(website, orderNumber)
    {
        console.log("Processed till :", website, orderNumber)
        const docRef = db.collection('Messold').doc(website).update(
        {
            orderNumber: orderNumber
        });
        // docRef.set(orderData)
        // console.log("Saved in Firebase", orderData.order_number)
    }

    function formatDate1(date)
    {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();
        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;
        return [year, month, day].join('-');
    }

    function getUTM(orderData, websiteUrl, access_token, sheetId, sequence)
    {
        console.log("Getting UTM", websiteUrl)
        fetch("https://" + websiteUrl + "/admin/api/graphql.json",
        {
            method: "POST",
            headers:
            {
                "Content-Type": "application/json",
                "X-Shopify-Access-Token": access_token
            },
            body: JSON.stringify(
            {
                query: `{
                  order(id: "gid://shopify/Order/` + orderData.id + `") 
                  { 
                    customerJourney {
                      firstVisit {
                        utmParameters {
                          campaign
                          medium
                          source
                          term
                          content
                        }
                      }
                      lastVisit {
                        utmParameters {
                          campaign
                          content
                          medium
                          source
                          term
                        }
                      }
                    }
                  }
                 }`
            })
        }).then(result =>
        {
            return result.json();
        }).then(data =>
        {
            console.log("Inside UTM", websiteUrl);
            var discountCode = "";
            if (orderData.discount_codes[0])
            {
                discountCode = orderData.discount_codes[0].code;
                discountCode.toUpperCase();
            }
            if (orderData.cancelled_at == null)
            {
                // if (discountCode.includes("MESSOLD"))
                // {
                //     // sendcomarketingemail('anuj@messold.com', orderData.billing_address.name, brandName, orderData.order_number, emailTemplate)
                // }
                // else
                // {
                //     if (orderData.email != null)
                //     {
                //         // sendcomarketingemail(orderData.email, orderData.billing_address.name, brandName, orderData.order_number, emailTemplate)
                //     }
                // }
                saveDataFirebase(orderData, websiteUrl)
            }
            saveDataExcel(orderData, data.data.order, websiteUrl, access_token, sheetId, sequence)
        });
    }
    async function saveDataExcel(orderData, UTM, websiteUrl, access_token, sheetId, sequence)
    {
        console.log("Under Save Data", websiteUrl);
        var sourceUTM = "";
        await doc.useServiceAccountAuth(
        {
            client_email: "parallers@parallels-messold.iam.gserviceaccount.com",
            private_key: "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC+O7SzqiRAwQGw\nxs3Bkd8Ju3iAX5u93Uh/uuRHQl8sTpx0djn8X0Uds5N90dOPTBY+LsUoBLmB1f6I\ncZ33tSgIV36/xz4entHRhNm0HWPjqklHub6o0vrUxEa11xdUp74ueXvXxdNv/Wyd\nhDgVGz1acaYrskmTGEq8KDNbq8o08ZpLqB6LT9+Vj6bONDgJAbs71LVNP0gOG8rI\nlt3RXq5ZYYDcDlvL2Dk5mLyWKjpYMihnbACkWsIErNeL1WTXDEA/lre1lNCq3y7b\nZU+BJyta3Pb9PVq78p8NRUImgy842UyLM45dsuDBiz1FLQcjIRFh9UhMmRqKulTu\nNAObs4F3AgMBAAECggEAEsMRZmrlxRvZY9Wns2tZ+RFr/WqbPKrsxz7n3CitTvxj\nLTqqgLvmCtuMNMDowbL6ZUr4Qk3SUf4zasJHQd1fGRDavRAUjgaR9mfI5PJvyKN3\nM24cDMs01p6TxBl2VptuBBK9O8xqDHCNMYKPLshkpl1Gdfwmii2/fovkd3/GTgRI\n7spc/mONXwoV2IjIGTHA7JCkQJKh3zJt8C5I82tQjIqgGJq3x3XxlrXRwsoKV8gP\nOCURhE6RNaFzwE8y9okA7fM+dLwIywN/Dfy+v5DxkTAlOwUACpiwkWrAKE61ENz5\nvhvLEvyRRGXgumfcR3iN83pn6nOyue4s96wKcEd7oQKBgQD6E6OxOTFAEoUJoeFl\n/+nXVgGUW5dDnbtMRS0Dre8HaVroayD1HRzvjJ7Kgbzp/oL/6f0Zk2NUytjM1k8j\nmyPWmpLWB2yzsea7uVBSjgDGUEttQSX/KGOksx3DzwORT1ZtNOxXmTE4OnPs8KJy\na/Lyp9/NcmtIJ3ySnbQC1teNMQKBgQDCvTNXoGLIBMJqsMfe6I5mX6uER9EwogEo\nPZDpXz5vsWN5AuIBe20oCZk/q5WnaVAJp7v2f2ygdHwnePSjoDfN5wSvGrKD6Bmf\nqFPuuAsquQtZeZIHPqrGW8P3oFN7IPHdMelu0Z33b/tY0jN5MH/7bGcDVxXQQ36L\nmSMYnMEvJwKBgQCLiVnVEWyBq9O/xCvYlisMlFjdRx3oBKL1s8OiQfMV15t6BAyn\nuE7k+zm/FRUsG29NDGrFUpAiR+0gnpQZ8f7VR/qWoh3tRl7QcF55MfMMtNDhbXCe\nJxMyWx9ImsIK2pIG7XjSiBAGp9b3Zm2+Gq286B7gq+9gm2fPB1/iFa7AgQKBgQC/\nV7v824Bz3AlTX4PjyEky2cnjXdVznZrZeTTLuWPVx0xf+K8smaP1dQj5AJU5O0cD\nVaZgW2/WcN4UwspNg/2Q+O8nRmolJYcX0wM1Seze+5blQYh0SeTupff1dbjRANvl\nZUdiNeCq4YLsEQ22hCscVbUaGRU73zWV4NAVPOCsfQKBgGZKtzICSAU8oprDGjgN\nLCooNx3HE9uYCNbeVZSgI8n40hkvir8XfxI54Nn9BUwNTtwWlxEFW2sE3rf7oPcC\nmImKVosfaqtSlNATTy4tmBvxdLcV229oMSihtakxMWATuA5I5I/KBh+yWpSNtLob\nxDyN4LEdKhy4YoctBR2Qk/9P\n-----END PRIVATE KEY-----\n",
        });
        await doc.loadInfo();
        var discountCode = "";
        var FVCampaign = "",
            FVMedium = "",
            FVContent = "",
            FVSource = "",
            FVTerm = "",
            LVCampaign = "",
            LVMedium = "",
            LVContent = "",
            LVSource = "",
            LVTerm = "",
            OriginalSource = "";
        if (orderData.discount_codes[0])
        {
            discountCode = orderData.discount_codes[0].code;
        }
        if (typeof(UTM) != 'undefined' && typeof(UTM.customerJourney) != 'undefined' && UTM.customerJourney != null)
        {
            if (typeof(UTM.customerJourney.firstVisit) != 'undefined' && UTM.customerJourney.firstVisit != null && typeof(UTM.customerJourney.firstVisit.utmParameters) != 'undefined' && UTM.customerJourney.firstVisit.utmParameters != null)
            {
                FVCampaign = UTM.customerJourney.firstVisit.utmParameters.campaign,
                    FVContent = UTM.customerJourney.firstVisit.utmParameters.content,
                    FVMedium = UTM.customerJourney.firstVisit.utmParameters.medium,
                    FVSource = UTM.customerJourney.firstVisit.utmParameters.source,
                    FVTerm = UTM.customerJourney.firstVisit.utmParameters.term;
                // sourceUTM = "DigitalMediaSales";
            }
            // console.log(typeof(UTM.customerJourney.lastVisit))
            if (typeof(UTM.customerJourney.lastVisit) != 'undefined' && UTM.customerJourney.lastVisit != null && typeof(UTM.customerJourney.lastVisit.utmParameters) != 'undefined' && UTM.customerJourney.lastVisit.utmParameters != null)
            {
                LVCampaign = UTM.customerJourney.lastVisit.utmParameters.campaign,
                    LVContent = UTM.customerJourney.lastVisit.utmParameters.content,
                    LVMedium = UTM.customerJourney.lastVisit.utmParameters.medium,
                    LVSource = UTM.customerJourney.lastVisit.utmParameters.source,
                    LVTerm = UTM.customerJourney.lastVisit.utmParameters.term;
                // sourceUTM = "DigitalMediaSales";
            }
        }
        if (orderData.referring_site !== null)
        {
            if (orderData.referring_site.includes("instagram"))
            {
                OriginalSource = "Instagram_"
            }
            else if (orderData.referring_site.includes("facebook") || orderData.referring_site.includes("fb"))
            {
                OriginalSource = "Facebook_"
            }
            else if (orderData.referring_site.includes("Google") || orderData.referring_site.includes("google"))
            {
                OriginalSource = "Google_"
            }
        }
        // console.log("dnjknk",orderData.referring_site)
        // var referringSite = orderData.
        // console.log(FVTerm, LVTerm, orderData.order_number)
        if (FVCampaign == "" && FVContent == "" && FVMedium == "" && FVSource == "" && FVTerm == "" && LVCampaign == "" && LVContent == "" && LVMedium == "" && LVSource == "" && LVTerm == "" && OriginalSource == "")
        {
            sourceUTM = "DirectSales";
        }
        else
        {
            if (OriginalSource != "") sourceUTM = OriginalSource + "OSales";
            else sourceUTM = "FB|Google|Sales";
        }
        var FirstCampaign = FVCampaign + "|" + FVContent + "|" + FVMedium + "|" + FVSource + "|" + FVTerm;
        var LastCampaign = LVCampaign + "|" + LVContent + "|" + LVMedium + "|" + LVSource + "|" + LVTerm;
        // else if (FVTerm == "" && LVTerm == "")
        // {
        //     sourceUTM = "Others"
        // }
        // else if (FVSource == "google" || LVSource == "google")
        // {
        //     sourceUTM = "Paid Media"
        // }
        // else if (FVTerm == "")
        // {
        //     sourceUTM = LVTerm;
        // }
        // else if (LVTerm == "")
        // {
        //     sourceUTM = FVTerm;
        // }
        // else
        // {
        //     console.log("Others ----->", orderData.order_number)
        //     sourceUTM = LVTerm;
        // }
        // console.log(sourceUTM, orderData.order_number)
        // console.log(websiteUrl, sheetId)
        var sheetIds = sheetId;
        var sheet = doc.sheetsById[sheetIds];
        // console.log(orderData)
        var orderDate = formatDate(orderData.created_at);
        // console.log("-------", orderData)
        const ParallelRow = await sheet.addRow(
        {
            'OrderNumber': orderData.order_number,
            'OrderDate': orderDate,
            'Attribute': sourceUTM,
            'SubTotal': orderData.subtotal_price,
            'Tax': orderData.total_tax,
            'Discount': orderData.total_discounts,
            'CancelledDate': cancelledDate,
            'First Campaign': FirstCampaign,
            'Last Campaign': LastCampaign
        }, function(err, data)
        {
            console.log("Saved", err)
        });
        var cancelledDate = "";
        // console.log("-----")
        if (orderData.cancelled_at != null)
        {
            cancelledDate = formatDate(orderData.cancelled_at);
            sourceUTM = "Returns_" + sourceUTM;
            const ParallelRow = await sheet.addRow(
            {
                'OrderNumber': 'Returns_' + orderData.order_number,
                'OrderDate': orderDate,
                'Attribute': sourceUTM,
                'SubTotal': -Math.abs(orderData.subtotal_price),
                'Tax': -Math.abs(orderData.total_tax),
                'Discount': -Math.abs(orderData.total_discounts),
                'CancelledDate': cancelledDate,
                'First Campaign': FirstCampaign,
                'Last Campaign': LastCampaign
            }, function(err, data)
            {
                console.log("Saved", err)
            });
        }
        if (sequence == 'continue')
        {
            orderData.order_number++;
            getOrder(orderData.order_number, websiteUrl, access_token, sheetId, sequence)
        }
    };

    function formatDate(date)
    {
        // console.log("Date", date)
        var onlyDate = date.split("T");
        return onlyDate[0];
    }

    function saveDataFirebase(orderData, brandName)
    {
        var orderNumber = JSON.stringify(orderData.order_number);
        const docRef = db.collection(JSON.stringify(brandName)).doc(orderNumber);
        docRef.set(orderData)
        // console.log("Saved in Firebase", orderData.order_number)
    }
    app.post('/stores', function(req, res)
    {
        console.log("trs");
    })
    app.get('/performance', function(req, res)
    {
        res.render('performancemodel.html')
    })
    app.get('/thankyou', function(req, res)
    {
        res.render("index.html")
    })
    app.get('/team', function(req, res)
    {
        res.render("team.html")
    })
    app.get('/meet', function(req, res)
    {
        res.render("meet.html")
    })
    app.get('/brandconnect', function(req, res)
    {
        res.render('brandconnect.html')
    })
    app.get('/.well-known/acme-challenge/:id', function(req, res)
    {
        res.send(req.params.id + '.-MJHO9AANppbG1NAsc3HGvv3VS5J3BpEbisQTq2xA6s');
    })
    app.post('/quote', function(req, res)
    {
        console.log(req.body)
        var transporter = nodemailer.createTransport(
        {
            service: "zoho",
            host: 'smtp.zoho.com',
            port: 465,
            secure: true, // use SSL
            auth:
            {
                user: 'anuj@messold.com',
                pass: 'muv7FiufVpSG'
            }
        });
        var bb = JSON.stringify(req.body)
        var mailOptions = {
            from: '"Anuj" <anuj@messold.com>', // sender address (who sends)
            to: 'a.anuj1405@gmail.com', // list of receivers (who receives)
            subject: 'New Request Quote', // Subject line
            text: bb, // plaintext body
        }
        transporter.sendMail(mailOptions, function(error, info)
        {
            if (error)
            {
                res.status(200);
                res.send('fail');
                return console.log("error", error);
            }
        });
        res.status(200);
        res.send('success');
    })
    app.get('/stock', function(req, res)
    {
        console.log(req)
    })
}