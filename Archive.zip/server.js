var express  = require('express');
var connect = require('connect');
var app      = express();
var fs = require('fs');
var port     = process.env.PORT || 443;
var bodyParser = require('body-parser');

var http = require('http');
var https = require('https');
// app.use(redirectToHTTPS([/localhost:(\d{4})/], [/\/insecure/], 301));
app.use(bodyParser.urlencoded({ extended: false }))
app.set('views', __dirname + '/views');
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/public'));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// app.all('*', ensureSecure); 
app.use('/robots.txt', function (req, res, next) {
    res.type('text/plain')
    res.send("User-agent: *\nallow: /");
});

require('./app/routes.js')(app,fs);

//Live----------------
var ssl = {
    key: fs.readFileSync('/etc/letsencrypt/live/messold.com/privkey.pem'),
    cert: fs.readFileSync('/etc/letsencrypt/live/messold.com/fullchain.pem'),
    ca: fs.readFileSync('/etc/letsencrypt/live/messold.com/chain.pem')
}
https.createServer(ssl, app).listen(443, () => {
    console.log('Listening...')
  })

http.createServer(function (req, res) {
    res.writeHead(301, { "Location": "https://" + req.headers['host'] + req.url });
    res.end();
}).listen(3000);
// app.enable('trust proxy')
// app.use((req, res, next) => {
//     req.secure ? next() : res.redirect('https://' + req.headers.host + req.url)
// })
//End------------------------
// app.listen(3000, function () {
//   console.log('NJIMPACT listening on port ' + port + '!');
// });


// function ensureSecure(req, res, next){f
//   var host = req.header("host");
//   console.log("--",req.hostname,req.url,req.headers['host']);
//   if(req.secure){
//     console.log("OK");
//     return next();
//   };
//   res.redirect('https://'+req.hostname + req.url); // express 4.x
// }






// app.listen(3000);


// // Redirect from http port 80 to https
// http.createServer(function (req, res) {
   
//     // res.end();
// }).listen(3000);



// app.listen(8080, function (req,res) {
//         res.writeHead(301, { "Location": "https://" + req.headers['host'] + req.url });
//         console.log('Express started on http://localhost:' + 3000 + '; press Ctrl-C to terminate.');
//     });

// // Redirect from http port 80 to https



// http.createServer(function (req, res) {
//    console.log("http to s")

// //	res.send("hello");
//     res.writeHead(301, { "Location": "https://" + req.headers['host'] + req.url });
//     res.end();
// }).listen(3000);




// https.createServer(ssl, app).listen(443, () => {
//     console.log('Listening...')
//   })


// console.log('The App runs on port ' + port);
